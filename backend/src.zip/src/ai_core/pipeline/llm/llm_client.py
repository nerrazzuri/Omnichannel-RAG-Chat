from typing import List, Optional, Dict, Any
import os
from openai import OpenAI

from shared.config.tuning import retrieval
from ai_core.pipeline.llm.prompt_orchestrator import PromptOrchestrator


class LLMClient:
    def __init__(self) -> None:
        api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=api_key) if api_key else None
        self.model = os.getenv("RAG_CHAT_MODEL", "gpt-5-mini")
        self.temperature = float(os.getenv("RAG_CHAT_TEMPERATURE", "0.3"))
        self._orchestrator = PromptOrchestrator()
        self._system_policy = (
            "You are Omni, a concise, factual enterprise assistant. Answer based only on provided context. "
            "If the answer is unknown in context, say so. Use [S#] tags to cite snippets after facts. "
            "Do not reveal chain-of-thought or internal reasoning."
        )

    def generate(self, query: str, contexts: List[str], intent: str = "lookup", result_hint: str | None = None) -> Dict[str, Any]:
        prompt = self._orchestrator.build_prompt(intent=intent, query=query, context_docs=contexts or [], result_hint=result_hint)
        if not self.client:
            # Local heuristic summarization fallback (no external calls)
            text = self._local_summarize(contexts or [result_hint or ""], intent=intent, result_hint=result_hint)
            return {"text": text, "used": False}
        try:
            completion = self.client.chat.completions.create(
                model=self.model,
                temperature=self.temperature,
                messages=[
                    {"role": "system", "content": self._system_policy},
                    {"role": "user", "content": prompt},
                ],
            )
            text = (completion.choices[0].message.content or "").strip()
            try:
                from shared.logging.pipeline_logger import PipelineLogger
                PipelineLogger("global").emit({
                    "llm_call": {
                        "template": intent,
                        "system_tokens": int(len(self._system_policy)/4),
                        "user_tokens": int(len(prompt)/4),
                        "has_result_hint": bool(result_hint),
                    }
                })
            except Exception:
                pass
            return {"text": text, "used": True}
        except Exception:
            text = self._local_summarize(contexts or [result_hint or ""], intent=intent, result_hint=result_hint)
            return {"text": text, "used": False}

    def _local_summarize(self, contexts: List[str], intent: str, result_hint: str | None) -> str:
        joined = " ".join(contexts[:3])
        # Split into sentences and keep top few
        parts = [p.strip() for p in joined.replace("\n", " ").split(".") if p.strip()]
        if intent == "summary":
            kept = parts[:5]
        elif intent == "lookup":
            kept = parts[:2]
        elif intent == "compare":
            kept = parts[:6]
        elif intent == "aggregate" and result_hint:
            return str(result_hint)
        else:
            kept = parts[:4]
        return ". ".join(kept) + ("." if kept else "")


