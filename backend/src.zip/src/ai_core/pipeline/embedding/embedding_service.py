from typing import List, Optional

import os
from openai import OpenAI

from shared.cache.redis import redis_cache
from shared.config.tuning import retrieval


class EmbeddingService:
    def __init__(self) -> None:
        api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=api_key) if api_key else None
        self.model = getattr(retrieval, 'embedding_model', os.getenv("RAG_EMBED_MODEL", "text-embedding-3-large"))

    def _cache_key(self, text: str) -> str:
        return f"emb:{self.model}:{hash(text)}"

    def embed_query(self, query: str, tenant_id: str) -> Optional[List[float]]:
        if not query or not self.client:
            return None
        k = self._cache_key(query)
        cached = redis_cache.get_tenant_key(tenant_id, k)
        if isinstance(cached, list):
            return cached
        try:
            resp = self.client.embeddings.create(model=self.model, input=[query])
            vec = resp.data[0].embedding if resp and resp.data else None
            if isinstance(vec, list):
                redis_cache.set_tenant_key(tenant_id, k, vec, ttl=1800)
                return vec
        except Exception:
            return None
        return None


